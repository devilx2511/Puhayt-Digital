import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AgencyProvider, useAgency } from "./context/AgencyContext";
import { SEOMeta } from "./components/SEO/SEOMeta";
import { PublicAdBanner } from "./components/PublicAdBanner";
import { Navbar } from "./components/Navbar";
import { MobileSlideDrawer } from "./components/MobileSlideDrawer";
import { ThreeBackground } from "./components/ThreeBackground";
import { HeroSection } from "./components/HeroSection";
import { AboutSection } from "./components/AboutSection";
import { ServicesSection } from "./components/ServicesSection";
import { PortfolioSection } from "./components/PortfolioSection";
import { IndustriesSection } from "./components/IndustriesSection";
import { AISuiteSection } from "./components/AISuiteSection";
import { TestimonialsSection } from "./components/TestimonialsSection";
import { PricingSection } from "./components/PricingSection";
import { BlogSection } from "./components/BlogSection";
import { ContactSection } from "./components/ContactSection";
import { Footer } from "./components/Footer";
import { FreeAuditModal } from "./components/FreeAuditModal";
import { SearchModal } from "./components/SearchModal";
import { DevModeModal } from "./components/DevMode/DevModeModal";
import { PaymentModal } from "./components/PaymentModal";
import { AuthModal } from "./components/AuthModal";
import { ClientDashboard } from "./components/ClientDashboard";
import { ScrollProgressBar } from "./components/ScrollProgressBar";
import { KolkataGeoSection } from "./components/KolkataGeoSection";
import { GoogleStitchOptionsModal } from "./components/GoogleStitchOptionsModal";

function MainAppContent() {
  const {
    showCaseStudies,
    currentUser,
    openAuthModal,
    isClientDashboardOpen,
    closeClientDashboard,
  } = useAgency();
  
  // App sequence state: defaults directly to "homepage" for instant mobile & desktop access
  const [appStage, setAppStage] = useState<"opening" | "loading" | "auth" | "homepage">("homepage");

  const [isAuditOpen, setIsAuditOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isOptionsOpen, setIsOptionsOpen] = useState(false);
  const [currentSection, setCurrentSection] = useState("home");
  const [selectedServiceForContact, setSelectedServiceForContact] = useState("");

  // When stage reaches "auth", trigger the Auth modal if not logged in
  useEffect(() => {
    if (appStage === "auth") {
      if (currentUser) {
        setAppStage("homepage");
      } else {
        openAuthModal("google");
      }
    }
  }, [appStage, currentUser, openAuthModal]);

  // If user signs in while on "auth" stage, automatically transition to "homepage"
  useEffect(() => {
    if (currentUser && (appStage === "opening" || appStage === "auth")) {
      // Allow user to proceed to homepage
      if (appStage === "auth") {
        setAppStage("homepage");
      }
    }
  }, [currentUser, appStage]);

  // ScrollSpy to track active visible section for bottom dock & navbar highlights
  useEffect(() => {
    if (appStage !== "homepage") return;

    const handleScrollSpy = () => {
      const sectionIds = ["home", "services", "portfolio", "ai-suite", "pricing", "testimonials", "about", "blog", "contact"];
      const scrollPosition = window.scrollY + 200;

      for (const id of sectionIds) {
        const el = document.getElementById(id);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setCurrentSection(id);
            return;
          }
        }
      }
      if (window.scrollY < 200) {
        setCurrentSection("home");
      }
    };

    window.addEventListener("scroll", handleScrollSpy, { passive: true });
    return () => window.removeEventListener("scroll", handleScrollSpy);
  }, [appStage]);

  const scrollToSection = (id: string) => {
    setCurrentSection(id);
    if (id === "home") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleSelectService = (serviceName: string) => {
    setSelectedServiceForContact(serviceName);
    scrollToSection("contact");
  };

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-white font-sans selection:bg-[#D4AF37] selection:text-[#0B0B0B] relative overflow-x-hidden">
      
      {/* Dynamic SEO Meta & JSON-LD Structured Data */}
      <SEOMeta />

      {/* Subtle Gold Horizontal Scroll Progress Bar */}
      <ScrollProgressBar isVisible={true} />

      {/* Public Advertisement Announcement Bar (Only visible when approved & published) */}
      <PublicAdBanner />

      {/* Main Sticky Navbar (Desktop + Mobile Header) */}
      <Navbar
        currentSection={currentSection}
        onOpenAudit={() => setIsAuditOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onNavigate={scrollToSection}
        onToggleDrawer={() => setIsDrawerOpen(true)}
        onOpenOptions={() => setIsOptionsOpen(true)}
      />

      {/* 3D WebGL Canvas Interactive Background */}
      <ThreeBackground />

      {/* Main Content Sections */}
      <main className="relative z-10">
        <HeroSection
          onOpenAudit={() => setIsAuditOpen(true)}
          onExploreServices={() => scrollToSection("services")}
        />

        <AboutSection />

        <ServicesSection onSelectService={handleSelectService} />

        {/* Dedicated Kolkata GEO Section for Local #1 Dominance */}
        <KolkataGeoSection onNavigateToContact={() => scrollToSection("contact")} />

        <PortfolioSection />

        <IndustriesSection />

        <AISuiteSection />

        <TestimonialsSection />

        <PricingSection onSelectPlan={(planName) => handleSelectService(`Pricing Plan: ${planName}`)} />

        <BlogSection />

        <ContactSection initialService={selectedServiceForContact} />
      </main>

      {/* Global Footer */}
      <Footer onNavigate={scrollToSection} />

      {/* Luxury Slide-over Drawer Panel */}
      <MobileSlideDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        currentSection={currentSection}
        onNavigate={scrollToSection}
        onOpenAudit={() => setIsAuditOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAISuite={() => scrollToSection("ai-suite")}
        onOpenOptions={() => setIsOptionsOpen(true)}
      />

      {/* Google Stitch Quick Options & Visual Hierarchical Sitemap Modal */}
      <GoogleStitchOptionsModal
        isOpen={isOptionsOpen}
        onClose={() => setIsOptionsOpen(false)}
        onNavigate={scrollToSection}
        onOpenAudit={() => setIsAuditOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Interactive Modals */}
      <FreeAuditModal
        isOpen={isAuditOpen}
        onClose={() => setIsAuditOpen(false)}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={scrollToSection}
      />

      {/* DevMode Settings Control Center */}
      <DevModeModal />

      {/* Client Checkout Payment Modal */}
      <PaymentModal />

      {/* Firebase Authentication Modal (Google, Email, Phone, Guest) */}
      <AuthModal />

      {/* Secure Client Dashboard (Shows after authentication) */}
      <ClientDashboard
        isOpen={isClientDashboardOpen}
        onClose={closeClientDashboard}
      />

    </div>
  );
}

export function App() {
  return (
    <AgencyProvider>
      <MainAppContent />
    </AgencyProvider>
  );
}

export default App;

