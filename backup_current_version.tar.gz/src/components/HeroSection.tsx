import React from "react";
import { Sparkles, ArrowRight, Play, Calendar, ShieldCheck, TrendingUp, Award, CheckCircle2, ChevronRight, BarChart3, Globe2, Crown } from "lucide-react";
import { ThreeBackground } from "./ThreeBackground";
import { useAgency } from "../context/AgencyContext";

interface HeroSectionProps {
  onStartProject?: () => void;
  onBookConsultation?: () => void;
  onViewPortfolio?: () => void;
  onOpenAudit?: () => void;
  onExploreServices?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartProject,
  onBookConsultation,
  onViewPortfolio,
  onOpenAudit,
  onExploreServices,
}) => {
  const { openClientDashboard } = useAgency();
  const handleStart = onStartProject || onOpenAudit || (() => {});
  const handleConsult = onBookConsultation || (() => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  });
  const handlePortfolio = onViewPortfolio || onExploreServices || (() => {
    document.getElementById("services")?.scrollIntoView({ behavior: "smooth" });
  });
  return (
    <section className="relative min-h-screen pt-32 pb-20 flex items-center justify-center overflow-hidden bg-[#0B0B0B]">
      {/* 3D WebGL Canvas Background */}
      <ThreeBackground interactive={true} />

      {/* Subtle Radial Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#D4AF37]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[400px] h-[400px] bg-[#B8860B]/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headline & Action Controls */}
          <div className="lg:col-span-7 text-left space-y-8">
            
            {/* Top Pill Badge */}
            <div className="inline-flex items-center space-x-2.5 glass-card-gold px-4 py-2 rounded-full border border-[#D4AF37]/30 shadow-lg animate-fadeIn">
              <span className="flex h-2 w-2 rounded-full bg-[#D4AF37] animate-ping" />
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-semibold tracking-wide text-[#D4AF37] uppercase">
                Awwwards-Level Digital Marketing & AI Agency
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.08]">
              We Don't Just Market Brands.{" "}
              <span className="gold-gradient-text block mt-2">
                We Build Digital Empires.
              </span>
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg text-neutral-300 max-w-2xl font-light leading-relaxed">
              We help ambitious businesses dominate online through bespoke 3D websites, technical SEO supremacy, hyper-profitable Google & Meta ads, luxury branding, and autonomous AI marketing pipelines.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3.5 sm:space-y-0 sm:space-x-4 pt-2">
              <button
                onClick={handleStart}
                className="px-7 py-4 rounded-full font-bold text-sm text-[#0B0B0B] gold-gradient-bg shadow-xl hover:shadow-[#D4AF37]/30 hover:scale-[1.03] active:scale-95 transition-all flex items-center justify-center space-x-2 group"
              >
                <span>Start Your Project</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={handleConsult}
                className="px-6 py-4 rounded-full font-semibold text-sm text-white glass-card hover:border-[#D4AF37]/50 hover:bg-white/10 transition-all flex items-center justify-center space-x-2 border border-white/15"
              >
                <Calendar className="w-4 h-4 text-[#D4AF37]" />
                <span>Book Free Consultation</span>
              </button>

              <button
                onClick={handlePortfolio}
                className="px-5 py-4 rounded-full text-xs font-semibold text-neutral-300 hover:text-white flex items-center justify-center space-x-1 transition-colors"
              >
                <span>View Portfolio</span>
                <ChevronRight className="w-4 h-4 text-[#D4AF37]" />
              </button>
            </div>

            {/* Direct Client Dashboard Badge / Access */}
            <div className="pt-2">
              <button
                onClick={openClientDashboard}
                className="inline-flex items-center space-x-2 text-xs font-mono text-[#FFDF73] bg-[#16120C]/80 hover:bg-[#201A10] border border-[#D4AF37]/40 hover:border-[#D4AF37] px-4 py-2 rounded-full transition-all shadow-sm hover:scale-[1.02]"
              >
                <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Client Member? Access Private Portal, Live Milestones &amp; Websites &rarr;</span>
              </button>
            </div>

            {/* Key Trust Signals */}
            <div className="pt-6 border-t border-white/10 grid grid-cols-3 gap-4 text-left">
              <div>
                <div className="font-serif text-2xl sm:text-3xl font-extrabold text-white gold-gradient-text">
                  $150M+
                </div>
                <div className="text-xs text-neutral-400 font-medium mt-1">
                  Client Revenue Generated
                </div>
              </div>

              <div>
                <div className="font-serif text-2xl sm:text-3xl font-extrabold text-white gold-gradient-text">
                  340+
                </div>
                <div className="text-xs text-neutral-400 font-medium mt-1">
                  Global Brands Scaled
                </div>
              </div>

              <div>
                <div className="font-serif text-2xl sm:text-3xl font-extrabold text-white gold-gradient-text">
                  98.4%
                </div>
                <div className="text-xs text-neutral-400 font-medium mt-1">
                  Client Retention Rate
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: 3D Interactive Device Frame & Live Analytics Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Outer Glowing Border Card */}
              <div className="relative glass-card p-4 sm:p-6 rounded-2xl border border-white/15 shadow-2xl animate-float-slow">
                
                {/* Header Mockup Controls */}
                <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
                  <div className="flex space-x-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500/80" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                    <div className="w-3 h-3 rounded-full bg-green-500/80" />
                  </div>
                  <div className="text-[11px] text-neutral-400 font-mono bg-white/5 px-3 py-1 rounded-full border border-white/10 flex items-center space-x-1">
                    <Globe2 className="w-3 h-3 text-[#D4AF37]" />
                    <span>puhayt.digital/live-campaign</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-[10px] text-emerald-400 font-semibold uppercase">LIVE</span>
                  </div>
                </div>

                {/* Simulated Live Analytics Dashboard Preview */}
                <div className="space-y-4">
                  <div className="bg-[#121212] p-4 rounded-xl border border-white/10">
                    <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                      <span>Meta & Google Ads ROAS</span>
                      <span className="text-emerald-400 font-semibold flex items-center">
                        <TrendingUp className="w-3 h-3 mr-1" /> +480%
                      </span>
                    </div>
                    <div className="font-serif text-3xl font-bold text-white">
                      8.42x <span className="text-xs font-sans text-[#D4AF37] font-normal">Average ROAS</span>
                    </div>
                    <div className="w-full bg-white/10 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div className="bg-gradient-to-r from-[#D4AF37] to-amber-500 h-full w-[84%]" />
                    </div>
                  </div>

                  {/* Grid Stats */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-[#121212] p-3 rounded-xl border border-white/10">
                      <div className="text-[10px] text-neutral-400">Google Search Rank</div>
                      <div className="text-xl font-bold text-emerald-400 mt-1 flex items-center justify-between">
                        <span>#1 Position</span>
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      </div>
                      <div className="text-[10px] text-neutral-500 mt-1">42 Transactional Keywords</div>
                    </div>

                    <div className="bg-[#121212] p-3 rounded-xl border border-white/10">
                      <div className="text-[10px] text-neutral-400">AI Chatbot Conversions</div>
                      <div className="text-xl font-bold text-[#D4AF37] mt-1 flex items-center justify-between">
                        <span>+340/mo</span>
                        <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                      </div>
                      <div className="text-[10px] text-neutral-500 mt-1">24/7 Auto Booking</div>
                    </div>
                  </div>

                  {/* Client Testimonial Pill */}
                  <div className="glass-card-gold p-3 rounded-xl border border-[#D4AF37]/30 flex items-center space-x-3">
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                      alt="Client Avatar"
                      className="w-10 h-10 rounded-full border border-[#D4AF37]/50 object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <p className="text-xs text-white font-medium italic">
                        "Puhayt Digital scaled our real estate revenue from $10M to $42M in 90 days."
                      </p>
                      <p className="text-[10px] text-[#D4AF37] font-semibold mt-0.5">
                        — Marcus Vance, Apex Luxury
                      </p>
                    </div>
                  </div>

                </div>

              </div>

              {/* Floating Floating Badge 1 */}
              <div className="absolute -top-6 -left-6 glass-card-gold px-3.5 py-2 rounded-xl border border-[#D4AF37]/40 shadow-xl hidden sm:flex items-center space-x-2 animate-bounce">
                <Award className="w-5 h-5 text-[#D4AF37]" />
                <div>
                  <div className="text-[10px] text-neutral-300 font-semibold">Ranked #1</div>
                  <div className="text-xs font-bold text-white">Digital Agency 2026</div>
                </div>
              </div>

              {/* Floating Badge 2 */}
              <div className="absolute -bottom-6 -right-6 glass-card px-4 py-2.5 rounded-xl border border-white/20 shadow-2xl hidden sm:flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <div>
                  <div className="text-[10px] text-neutral-400">Guaranteed ROI</div>
                  <div className="text-xs font-bold text-white">Data-Driven Growth</div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
