import React from "react";
import { 
  X, 
  Compass, 
  Layers, 
  Briefcase, 
  Sparkles, 
  Bot, 
  CreditCard, 
  Star, 
  Phone, 
  LogIn, 
  ShieldCheck, 
  MessageCircle,
  Calculator,
  Lock,
  ChevronRight,
  Send,
  Crown,
  SlidersHorizontal,
  MapPin,
  Building2,
  BookOpen,
  FileText
} from "lucide-react";
import { useAgency } from "../context/AgencyContext";
import { BrandLogo } from "./BrandLogo";
import { motion, AnimatePresence } from "motion/react";

interface MobileSlideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenAudit: () => void;
  onOpenSearch: () => void;
  onOpenAISuite: () => void;
  onOpenOptions?: () => void;
}

export const MobileSlideDrawer: React.FC<MobileSlideDrawerProps> = ({
  isOpen,
  onClose,
  currentSection,
  onNavigate,
  onOpenAudit,
  onOpenSearch,
  onOpenAISuite,
  onOpenOptions,
}) => {
  const {
    openDevMode,
    contactInfo,
    isDevModeAuthenticated,
    currentUser,
    userProfile,
    openAuthModal,
    logout,
    openClientDashboard,
  } = useAgency();

  const handleItemClick = (action: () => void) => {
    action();
    onClose();
  };

  const primaryWhatsapp = contactInfo?.whatsapps?.[0] || "+919876543210";
  const cleanWhatsapp = primaryWhatsapp.replace(/[^0-9]/g, "");

  const navMenuItems = [
    {
      id: "home",
      title: "HOME EXPERIENCE",
      badge: "Main",
      badgeClass: "bg-[#451414] text-[#FFDF73] border border-[#D4AF37]/40",
      icon: Compass,
      onClick: () => onNavigate("home"),
    },
    {
      id: "kolkata-geo",
      title: "KOLKATA HQ & SERVICES",
      badge: "Sector V",
      badgeClass: "bg-[#2A1E0E] text-[#FFDF73] border border-[#D4AF37]/40 font-bold",
      icon: MapPin,
      onClick: () => onNavigate("kolkata-geo"),
    },
    {
      id: "services",
      title: "DIGITAL SERVICES & DEV",
      badge: "12 Services",
      badgeClass: "bg-[#3D260D] text-[#FFDF73] border border-[#D4AF37]/30",
      icon: Layers,
      onClick: () => onNavigate("services"),
    },
    {
      id: "portfolio",
      title: "PORTFOLIO & WORK",
      badge: "Live Proof",
      badgeClass: "bg-[#1A2E1A] text-emerald-300 border border-emerald-500/30",
      icon: Briefcase,
      onClick: () => onNavigate("portfolio"),
    },
    {
      id: "industries",
      title: "INDUSTRIES WE SERVE",
      badge: "Sectors",
      badgeClass: "bg-[#18233C] text-blue-300 border border-blue-500/30",
      icon: Building2,
      onClick: () => onNavigate("industries"),
    },
    {
      id: "ai-suite",
      title: "PUHAYT AI MARKETING SUITE",
      badge: "Gemini",
      badgeClass: "bg-gradient-to-r from-[#4A1515] to-[#2B0B0B] text-[#FFDF73] border border-[#D4AF37]/50",
      icon: Bot,
      onClick: () => onNavigate("ai-suite"),
    },
    {
      id: "pricing",
      title: "TRANSPARENT PRICING & ROI",
      badge: "Packages",
      badgeClass: "bg-[#1E293B] text-sky-300 border border-sky-500/30",
      icon: CreditCard,
      onClick: () => onNavigate("pricing"),
    },
    {
      id: "testimonials",
      title: "CLIENT REVIEWS & TRUST",
      badge: "5.0 Stars",
      badgeClass: "bg-[#3D260D] text-[#FFDF73] border border-[#D4AF37]/30",
      icon: Star,
      onClick: () => onNavigate("testimonials"),
    },
    {
      id: "about",
      title: "ABOUT PUHAYT DIGITAL",
      badge: "Agency Team",
      badgeClass: "bg-[#251D10] text-[#FFDF73] border border-[#D4AF37]/30",
      icon: ShieldCheck,
      onClick: () => onNavigate("about"),
    },
    {
      id: "blog",
      title: "TECH & STRATEGY BLOG",
      badge: "Articles",
      badgeClass: "bg-[#1A1A2E] text-purple-300 border border-purple-500/30",
      icon: BookOpen,
      onClick: () => onNavigate("blog"),
    },
    {
      id: "contact",
      title: "CONTACT & CALENDLY DESK",
      badge: "Direct",
      badgeClass: "bg-[#0E2818] text-emerald-300 border border-emerald-500/40",
      icon: Phone,
      onClick: () => onNavigate("contact"),
    },
    {
      id: "audit",
      title: "FREE INSTANT SEO AUDIT",
      badge: "Live Score",
      badgeClass: "bg-gradient-to-r from-[#FFDF73] to-[#D4AF37] text-black font-bold",
      icon: Sparkles,
      onClick: () => onOpenAudit(),
    },
    {
      id: "client-portal",
      title: "CLIENT PORTAL & WEBSITES",
      badge: currentUser ? "Private Dashboard" : "Sign In",
      badgeClass: "bg-[#2E1E09] text-[#FFDF73] border border-[#D4AF37]/50 font-bold",
      icon: Crown,
      onClick: () => openClientDashboard(),
    },
    {
      id: "stitch-options",
      title: "GOOGLE STITCH SUITE & SITEMAP",
      badge: "Options Hub",
      badgeClass: "bg-[#251D10] text-[#FFDF73] border border-[#D4AF37]/50 font-bold",
      icon: SlidersHorizontal,
      onClick: () => {
        if (onOpenOptions) onOpenOptions();
      },
    },
    {
      id: "devmode",
      title: "DEVMODE MASTER CONSOLE",
      badge: isDevModeAuthenticated ? "Active" : "Protected",
      badgeClass: "bg-[#451414] text-[#FFDF73] border border-[#D4AF37]/50",
      icon: Lock,
      onClick: () => openDevMode(),
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
          
          {/* Backdrop Blur Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            aria-hidden="true"
          />

          {/* Luxury Slide-over Drawer Panel */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 280 }}
            className="relative w-full max-w-sm sm:max-w-md bg-[#0A0806] border-l border-[#D4AF37]/40 h-full shadow-[0_0_50px_rgba(0,0,0,0.95)] flex flex-col z-50 overflow-y-auto"
          >
            {/* Ambient Gold Header Line */}
            <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-[#8B6508] via-[#FFDF73] to-[#8B6508]" />

            <div className="p-5 sm:p-6 space-y-5 flex-1 pb-24">
              
              {/* Header: Logo and Close Button */}
              <div className="flex items-center justify-between pb-3 border-b border-[#D4AF37]/20">
                <BrandLogo size="md" showTagline={true} />

                <button
                  onClick={onClose}
                  aria-label="Close Drawer"
                  className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 flex items-center justify-center transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* VIP / Firebase Auth Session Card */}
              <div className="bg-gradient-to-br from-[#1A140E] to-[#0E0B07] border border-[#D4AF37]/40 rounded-2xl p-4 shadow-lg flex items-center justify-between relative overflow-hidden">
                <div className="relative z-10">
                  <div className="text-[11px] font-extrabold tracking-wider uppercase text-white font-serif flex items-center gap-1.5">
                    <span>{currentUser ? (userProfile?.displayName || "AUTHENTICATED CLIENT") : "GUEST MODE"}</span>
                    {currentUser && (
                      <span className="text-[9px] bg-[#FFDF73]/20 text-[#FFDF73] font-mono px-1.5 py-0.2 rounded uppercase">
                        {userProfile?.authProvider || "Auth"}
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-[#C5B396] font-light mt-0.5 truncate max-w-[180px]">
                    {currentUser
                      ? (currentUser.email || currentUser.phoneNumber || "Instant Guest Session Active")
                      : "Sign in for VIP client tools & portal"}
                  </div>
                </div>

                {currentUser ? (
                  <button
                    onClick={async () => {
                      await logout();
                      onClose();
                    }}
                    className="relative z-10 px-3 py-1.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 font-extrabold text-[11px] tracking-wide flex items-center space-x-1 hover:bg-red-900/60 transition-colors"
                  >
                    <span>SIGN OUT</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleItemClick(() => openAuthModal("google"))}
                    className="relative z-10 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#E6C665] to-[#C99E2A] text-black font-extrabold text-[11px] tracking-wide flex items-center space-x-1 shadow-md hover:scale-105 transition-transform"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>LOG IN</span>
                  </button>
                )}
              </div>

              {/* Action Buttons Row: WhatsApp & Flavour/Puhayt AI */}
              <div className="grid grid-cols-2 gap-2.5">
                {/* WhatsApp Button */}
                <a
                  href={`https://wa.me/${cleanWhatsapp}?text=Hi%20Puhayt%20Digital,%20I%20would%20like%20to%20discuss%20a%20project.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-3 px-3 rounded-2xl bg-[#00A859] hover:bg-[#008F4C] text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow-[0_4px_15px_rgba(0,168,89,0.3)] transition-all hover:scale-[1.02]"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>WhatsApp</span>
                </a>

                {/* Puhayt AI Button */}
                <button
                  onClick={() => handleItemClick(onOpenAISuite)}
                  className="py-3 px-3 rounded-2xl bg-gradient-to-br from-[#541616] via-[#380E0E] to-[#1C0606] border border-[#D4AF37]/50 text-[#FFDF73] font-bold text-xs flex items-center justify-center space-x-1.5 shadow-[0_4px_15px_rgba(84,22,22,0.4)] transition-all hover:scale-[1.02]"
                >
                  <Bot className="w-4 h-4 text-[#FFDF73]" />
                  <span>Puhayt AI ✨</span>
                </button>
              </div>

              {/* Navigation Menu Header */}
              <div className="pt-2">
                <div className="text-[10px] uppercase tracking-[0.2em] font-extrabold text-[#D4AF37] mb-2.5 px-1">
                  Navigation Menu
                </div>

                {/* Navigation Items List */}
                <div className="space-y-2">
                  {navMenuItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = currentSection === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleItemClick(item.onClick)}
                        className={`w-full p-3 rounded-2xl flex items-center justify-between text-left transition-all border ${
                          isActive
                            ? "bg-gradient-to-r from-[#421212] via-[#240A0A] to-[#140505] border-[#D4AF37] shadow-[0_0_15px_rgba(212,175,55,0.25)]"
                            : "bg-[#120F0C]/90 hover:bg-[#1C1813] border-white/10 hover:border-[#D4AF37]/40"
                        }`}
                      >
                        <div className="flex items-center space-x-3 min-w-0">
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                            isActive ? "bg-[#D4AF37]/20 text-[#FFDF73]" : "bg-white/5 text-neutral-400"
                          }`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <span className={`text-xs font-bold tracking-tight truncate ${
                            isActive ? "text-white" : "text-neutral-200"
                          }`}>
                            {item.title}
                          </span>
                        </div>

                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${item.badgeClass}`}>
                          {item.badge}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Bottom Quick CTA: Free Website Audit & Search */}
              <div className="pt-4 border-t border-white/10 space-y-2.5">
                <button
                  onClick={() => handleItemClick(onOpenAudit)}
                  className="w-full py-3 px-4 rounded-2xl gold-gradient-bg text-black font-extrabold text-xs flex items-center justify-center space-x-2 shadow-[0_4px_20px_rgba(212,175,55,0.4)]"
                >
                  <Sparkles className="w-4 h-4 text-black" />
                  <span>CLAIM FREE 45-POINT AUDIT</span>
                </button>

                <button
                  onClick={() => handleItemClick(onOpenSearch)}
                  className="w-full py-2.5 px-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 text-xs flex items-center justify-between"
                >
                  <span className="flex items-center space-x-2">
                    <Compass className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Quick Command Search</span>
                  </span>
                  <kbd className="text-[9px] bg-white/10 px-1.5 py-0.5 rounded font-mono text-neutral-400">⌘K</kbd>
                </button>
              </div>

            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
