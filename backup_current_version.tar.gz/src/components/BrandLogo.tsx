import React, { useState } from "react";
import { Sparkles, Crown, Shield, Flame, Gem, Zap, Globe } from "lucide-react";
import { useAgency } from "../context/AgencyContext";

interface BrandLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  variant?: "full" | "icon-only" | "text-only";
  onClick?: () => void;
  showTagline?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = "",
  size = "md",
  variant = "full",
  onClick,
  showTagline = false,
}) => {
  const { brandLogo } = useAgency();
  const [imageError, setImageError] = useState(false);

  // Safe fallbacks to prevent ANY white screen errors or undefined issues
  const logoUrl = brandLogo?.logoUrl?.trim();
  const brandName = brandLogo?.brandName?.trim() || "PUHAYT";
  const brandSuffix = brandLogo?.brandSuffix?.trim() || "DIGITAL";
  const tagline = brandLogo?.tagline?.trim() || "Digital Growth Agency";
  const emblemLetter = (brandLogo?.emblemLetter?.trim() || brandName.charAt(0) || "P").toUpperCase();
  const showDot = brandLogo?.showDot !== false;
  const emblemIcon = brandLogo?.emblemIcon || "sparkles";
  const emblemGradient = brandLogo?.emblemGradient || "gold";
  const logoType = brandLogo?.logoType || (logoUrl ? "custom_image" : "emblem_letter");

  // Gradient styles for fallback emblem
  const gradientStyles: Record<string, string> = {
    gold: "from-[#FFE57F] via-[#D4AF37] to-[#8C6D1F] border-[#D4AF37]/50 text-black",
    cyber: "from-cyan-400 via-blue-500 to-indigo-600 border-cyan-400/50 text-white",
    ruby: "from-rose-400 via-red-500 to-amber-600 border-rose-400/50 text-white",
    emerald: "from-emerald-400 via-teal-500 to-green-700 border-emerald-400/50 text-black",
    platinum: "from-neutral-100 via-neutral-300 to-neutral-500 border-neutral-300/50 text-black",
  };

  const selectedGradient = gradientStyles[emblemGradient] || gradientStyles.gold;

  // Sizing definitions
  const sizeConfig = {
    sm: {
      box: "w-7 h-7 min-w-[28px]",
      img: "h-7 max-w-[120px]",
      icon: "w-3.5 h-3.5",
      text: "text-sm",
      subText: "text-[9px]",
      tag: "text-[8px]",
    },
    md: {
      box: "w-9 h-9 min-w-[36px]",
      img: "h-9 max-w-[160px]",
      icon: "w-4 h-4",
      text: "text-base sm:text-lg",
      subText: "text-xs",
      tag: "text-[9px]",
    },
    lg: {
      box: "w-11 h-11 min-w-[44px]",
      img: "h-11 max-w-[200px]",
      icon: "w-5 h-5",
      text: "text-xl sm:text-2xl",
      subText: "text-sm",
      tag: "text-[10px]",
    },
    xl: {
      box: "w-14 h-14 min-w-[56px]",
      img: "h-14 max-w-[260px]",
      icon: "w-7 h-7",
      text: "text-2xl sm:text-3xl",
      subText: "text-base",
      tag: "text-xs",
    },
  };

  const cfg = sizeConfig[size] || sizeConfig.md;

  const renderEmblemIcon = () => {
    switch (emblemIcon) {
      case "crown":
        return <Crown className={cfg.icon} />;
      case "shield":
        return <Shield className={cfg.icon} />;
      case "flame":
        return <Flame className={cfg.icon} />;
      case "gem":
        return <Gem className={cfg.icon} />;
      case "zap":
        return <Zap className={cfg.icon} />;
      case "globe":
        return <Globe className={cfg.icon} />;
      case "sparkles":
      default:
        return <Sparkles className={cfg.icon} />;
    }
  };

  // Render the visual logo mark
  const renderLogoMark = () => {
    // If a custom image exists and hasn't errored
    if (logoType === "custom_image" && logoUrl && !imageError) {
      return (
        <div className="relative flex items-center justify-center shrink-0">
          <img
            src={logoUrl}
            alt={brandName}
            className={`${cfg.img} object-contain rounded-lg drop-shadow-[0_2px_10px_rgba(212,175,55,0.25)] transition-transform duration-300 group-hover:scale-105`}
            onError={() => setImageError(true)}
            referrerPolicy="no-referrer"
          />
        </div>
      );
    }

    // Emblem with Icon
    if (logoType === "emblem_icon") {
      return (
        <div
          className={`${cfg.box} rounded-xl bg-gradient-to-tr ${selectedGradient} border p-0.5 flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.25)] transition-transform duration-300 group-hover:scale-105 shrink-0`}
        >
          {renderEmblemIcon()}
        </div>
      );
    }

    // Emblem with Letter (Default Puhayt Monogram)
    return (
      <div
        className={`${cfg.box} rounded-xl bg-gradient-to-tr ${selectedGradient} border flex items-center justify-center font-black font-serif shadow-[0_0_15px_rgba(212,175,55,0.25)] transition-transform duration-300 group-hover:scale-105 shrink-0`}
      >
        <span className="leading-none text-current font-extrabold">{emblemLetter}</span>
      </div>
    );
  };

  // Icon only
  if (variant === "icon-only") {
    return (
      <div
        onClick={onClick}
        className={`inline-flex items-center justify-center cursor-pointer group ${className}`}
        id="brand-logo-icon"
      >
        {renderLogoMark()}
      </div>
    );
  }

  // Text only
  if (variant === "text-only") {
    return (
      <div
        onClick={onClick}
        className={`flex flex-col cursor-pointer leading-none group select-none ${className}`}
        id="brand-logo-text"
      >
        <div className={`font-serif font-black tracking-wider text-white ${cfg.text} flex items-center gap-1`}>
          <span>{brandName}</span>
          {showDot && <span className="text-[#D4AF37]">.</span>}
          {brandSuffix && (
            <span className={`text-[#D4AF37] font-medium tracking-widest ${cfg.subText}`}>
              {brandSuffix}
            </span>
          )}
        </div>
        {showTagline && tagline && (
          <span className={`text-neutral-400 font-sans tracking-wide mt-0.5 ${cfg.tag}`}>
            {tagline}
          </span>
        )}
      </div>
    );
  }

  // Full: Mark + Text
  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 sm:gap-3 cursor-pointer group select-none ${className}`}
      id="brand-logo-full"
    >
      {renderLogoMark()}

      <div className="flex flex-col leading-none">
        <div className={`font-serif font-black tracking-wider text-white ${cfg.text} flex items-center gap-1`}>
          <span className="transition-colors group-hover:text-[#FFF2B2]">{brandName}</span>
          {showDot && <span className="text-[#D4AF37]">.</span>}
          {brandSuffix && (
            <span className={`text-[#D4AF37] font-medium tracking-widest ${cfg.subText}`}>
              {brandSuffix}
            </span>
          )}
        </div>
        {showTagline && tagline && (
          <span className={`text-neutral-400 font-sans tracking-wide mt-1 font-normal ${cfg.tag}`}>
            {tagline}
          </span>
        )}
      </div>
    </div>
  );
};
