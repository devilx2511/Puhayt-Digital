import React from "react";
import { GoogleMapLocation } from "./GoogleMapLocation";
import { Sparkles, CheckCircle2, ShieldCheck, Award } from "lucide-react";

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-[#0B0B0B] relative overflow-hidden border-t border-white/10">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center space-x-2 glass-card-gold px-3.5 py-1.5 rounded-full border border-[#D4AF37]/30 text-xs font-semibold text-[#D4AF37] uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Excellence In Execution</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            About <span className="gold-gradient-text">Puhayt Digital</span>
          </h2>

          <p className="text-neutral-400 text-base sm:text-lg font-light leading-relaxed">
            We are an elite team of senior digital architects, brand designers, SEO directors, and AI engineers who craft high-performing digital engines for ambitious brands.
          </p>
        </div>

        {/* Story & Mission Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          
          <div className="glass-card p-8 rounded-3xl border border-white/10 space-y-4">
            <h3 className="font-serif text-2xl font-bold text-white">Our Mission</h3>
            <p className="text-sm text-neutral-300 font-light leading-relaxed">
              To eradicate generic, low-converting digital presence and replace it with Apple-tier design, sub-second web speed, and autonomous AI marketing systems that guarantee high-margin client growth.
            </p>
            <div className="pt-4 border-t border-white/10 grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2 text-xs text-[#D4AF37]">
                <CheckCircle2 className="w-4 h-4" />
                <span>Zero Subcontracting</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-[#D4AF37]">
                <CheckCircle2 className="w-4 h-4" />
                <span>Transparent Growth SLAs</span>
              </div>
            </div>
          </div>

          <div className="glass-card p-8 rounded-3xl border border-white/10 space-y-4">
            <h3 className="font-serif text-2xl font-bold text-white">Core Pillars</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3 text-xs text-neutral-300">
                <span className="font-bold text-[#D4AF37]">01. Precision Craftsmanship:</span>
                <span>Every line of code and visual pixel is engineered for perfection.</span>
              </div>
              <div className="flex items-start space-x-3 text-xs text-neutral-300">
                <span className="font-bold text-[#D4AF37]">02. Verified ROI Data:</span>
                <span>Campaign decisions are driven strictly by validated revenue metrics.</span>
              </div>
              <div className="flex items-start space-x-3 text-xs text-neutral-300">
                <span className="font-bold text-[#D4AF37]">03. Autonomous AI Systems:</span>
                <span>We leverage custom fine-tuned Gemini models for exponential scale.</span>
              </div>
            </div>
          </div>

        </div>

        {/* Agency HQ Location Google Map Section */}
        <div className="mt-8">
          <GoogleMapLocation />
        </div>

      </div>
    </section>
  );
};

