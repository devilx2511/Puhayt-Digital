import React, { useState } from "react";
import { Sparkles, Bot, Send, FileText, CheckCircle2, ArrowRight, RefreshCw, Cpu, MessageSquare } from "lucide-react";
import ReactMarkdown from "react-markdown";

export const AISuiteSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"chat" | "proposal">("chat");

  // Chat State
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<
    { sender: "user" | "ai"; text: string }[]
  >([
    {
      sender: "ai",
      text: "Greetings! I am **Puhayt AI**, Chief Growth Strategist at Puhayt Digital. Ask me anything about scaling your SEO rankings, optimizing Google & Meta Ads, or building a high-converting 3D web platform.",
    },
  ]);
  const [chatLoading, setChatLoading] = useState(false);

  // Proposal Generator State
  const [proposalForm, setProposalForm] = useState({
    companyName: "",
    goals: "Scale revenue to $500k/mo and capture #1 Google Search ranking",
    targetAudience: "High-Net-Worth Individuals & Enterprise Decision Makers",
    monthlyBudget: "$10,000 - $25,000 / mo",
  });
  const [proposalLoading, setProposalLoading] = useState(false);
  const [proposalResult, setProposalResult] = useState<any>(null);

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;

    const userMsg = chatInput.trim();
    setChatMessages((prev) => [...prev, { sender: "user", text: userMsg }]);
    setChatInput("");
    setChatLoading(true);

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg }),
      });
      const data = await response.json();
      setChatMessages((prev) => [
        ...prev,
        { sender: "ai", text: data.response || "I am ready to assist with your growth strategy." },
      ]);
    } catch (err) {
      setChatMessages((prev) => [
        ...prev,
        {
          sender: "ai",
          text: "Puhayt AI is optimizing... Here is our core recommendation: Combine custom 3D WebGL user experiences with programmatic Technical SEO to maximize conversion rates.",
        },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  const handleGenerateProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!proposalForm.companyName) return;

    setProposalLoading(true);
    setProposalResult(null);

    try {
      const response = await fetch("/api/ai/proposal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(proposalForm),
      });
      const data = await response.json();
      setProposalResult(data);
    } catch (err) {
      setProposalResult({
        proposalTitle: `Puhayt Growth Blueprint for ${proposalForm.companyName}`,
        executiveSummary: `Tailored high-performance strategy designed to maximize ROI, scale lead acquisition, and dominate search rankings.`,
        recommendedServices: [
          { name: "3D Custom Web & Experience Design", cost: "$8,500 one-time", roi: "3.5x Conversion Boost" },
          { name: "Omnichannel SEO & Content Engine", cost: "$4,500 / mo", roi: "Top 3 Ranking in 90 Days" },
          { name: "Meta & Google Ads Performance Scaling", cost: "$3,500 / mo", roi: "4.2x ROAS Targeted" }
        ],
        expected6MonthRevenue: "$180,000 - $350,000+",
        timelineWeeks: 6
      });
    } finally {
      setProposalLoading(false);
    }
  };

  return (
    <section id="ai-suite" className="py-24 bg-[#0B0B0B] relative overflow-hidden border-t border-white/10">
      
      {/* Glow Effects */}
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center space-x-2 glass-card-gold px-3.5 py-1.5 rounded-full border border-[#D4AF37]/30 text-xs font-semibold text-[#D4AF37] uppercase tracking-wider">
            <Cpu className="w-3.5 h-3.5" />
            <span>Autonomous Intelligence Suite</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Puhayt <span className="gold-gradient-text">AI Growth Engine</span>
          </h2>

          <p className="text-neutral-400 text-base sm:text-lg font-light leading-relaxed">
            Experience our server-side AI marketing consultant or generate an instant, customized digital growth proposal for your company in seconds.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex justify-center gap-3 mb-12">
          <button
            onClick={() => setActiveTab("chat")}
            className={`px-5 py-3 rounded-full text-xs font-semibold transition-all flex items-center space-x-2 ${
              activeTab === "chat"
                ? "gold-gradient-bg text-[#0B0B0B] shadow-xl scale-105"
                : "glass-card text-neutral-300 hover:text-white"
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>AI Marketing Consultant</span>
          </button>

          <button
            onClick={() => setActiveTab("proposal")}
            className={`px-5 py-3 rounded-full text-xs font-semibold transition-all flex items-center space-x-2 ${
              activeTab === "proposal"
                ? "gold-gradient-bg text-[#0B0B0B] shadow-xl scale-105"
                : "glass-card text-neutral-300 hover:text-white"
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>AI Instant Proposal Generator</span>
          </button>
        </div>

        {/* TAB 1: AI CHAT CONSULTANT */}
        {activeTab === "chat" && (
          <div className="glass-card p-6 rounded-3xl border border-white/10 max-w-4xl mx-auto space-y-4 animate-fadeIn">
            
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full gold-gradient-bg p-[1px]">
                  <div className="w-full h-full bg-[#0B0B0B] rounded-full flex items-center justify-center">
                    <Bot className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-white">Puhayt AI Chief Strategist</h3>
                  <p className="text-[10px] text-emerald-400 font-mono">● Online & Ready to Advise</p>
                </div>
              </div>

              <div className="text-[11px] text-neutral-400 font-mono bg-white/5 px-3 py-1 rounded-full border border-white/10">
                Powered by Gemini AI
              </div>
            </div>

            {/* Chat Messages Window */}
            <div className="h-96 overflow-y-auto space-y-4 p-4 bg-black/50 rounded-2xl border border-white/5">
              {chatMessages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] sm:max-w-[75%] p-4 rounded-2xl text-xs leading-relaxed ${
                      msg.sender === "user"
                        ? "gold-gradient-bg text-[#0B0B0B] font-semibold rounded-br-none shadow-md"
                        : "glass-card text-neutral-200 border border-white/10 rounded-bl-none"
                    }`}
                  >
                    {msg.sender === "ai" ? (
                      <div className="markdown-body">
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                      </div>
                    ) : (
                      <span>{msg.text}</span>
                    )}
                  </div>
                </div>
              ))}

              {chatLoading && (
                <div className="flex justify-start">
                  <div className="glass-card p-3 rounded-2xl text-xs text-neutral-400 flex items-center space-x-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#D4AF37]" />
                    <span>Puhayt AI is generating strategy...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Chat Input */}
            <form onSubmit={handleSendChat} className="flex gap-2 pt-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask about SEO, Meta Ads strategy, or custom 3D web design..."
                className="flex-1 px-4 py-3 bg-black/70 border border-white/20 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37]"
              />
              <button
                type="submit"
                disabled={chatLoading}
                className="px-5 py-3 gold-gradient-bg text-[#0B0B0B] font-bold text-xs rounded-xl shadow-lg hover:scale-105 transition-transform flex items-center space-x-1"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

          </div>
        )}

        {/* TAB 2: AI PROPOSAL GENERATOR */}
        {activeTab === "proposal" && (
          <div className="glass-card p-6 sm:p-10 rounded-3xl border border-white/10 max-w-4xl mx-auto space-y-8 animate-fadeIn">
            <div>
              <h3 className="font-serif text-2xl font-bold text-white mb-2">
                Generate Custom AI Digital Growth Proposal
              </h3>
              <p className="text-xs text-neutral-400">
                Input your company details to generate a tailored 6-month growth roadmap with ROI projections and scope.
              </p>
            </div>

            <form onSubmit={handleGenerateProposal} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Company / Brand Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Apex Global Group"
                    value={proposalForm.companyName}
                    onChange={(e) => setProposalForm({ ...proposalForm, companyName: e.target.value })}
                    className="w-full px-4 py-3 bg-black/60 border border-white/20 rounded-xl text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Monthly Budget Range</label>
                  <select
                    value={proposalForm.monthlyBudget}
                    onChange={(e) => setProposalForm({ ...proposalForm, monthlyBudget: e.target.value })}
                    className="w-full px-4 py-3 bg-black/60 border border-white/20 rounded-xl text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                  >
                    <option value="$5,000 - $10,000 / mo">$5,000 - $10,000 / mo (Starter)</option>
                    <option value="$10,000 - $25,000 / mo">$10,000 - $25,000 / mo (Scale)</option>
                    <option value="$25,000+ / mo">$25,000+ / mo (Empire)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Primary Growth Goal</label>
                <input
                  type="text"
                  value={proposalForm.goals}
                  onChange={(e) => setProposalForm({ ...proposalForm, goals: e.target.value })}
                  className="w-full px-4 py-3 bg-black/60 border border-white/20 rounded-xl text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <button
                type="submit"
                disabled={proposalLoading}
                className="w-full py-3.5 gold-gradient-bg text-[#0B0B0B] font-bold text-xs rounded-xl shadow-lg hover:scale-[1.01] transition-transform flex items-center justify-center space-x-2"
              >
                {proposalLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Synthesizing Growth Roadmap...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate Custom AI Proposal</span>
                  </>
                )}
              </button>
            </form>

            {/* Proposal Output Card */}
            {proposalResult && (
              <div className="glass-card-gold p-6 rounded-2xl border border-[#D4AF37]/40 space-y-6 animate-fadeIn">
                <div className="flex items-center justify-between pb-4 border-b border-[#D4AF37]/30">
                  <h4 className="font-serif text-xl font-bold gold-gradient-text">
                    {proposalResult.proposalTitle}
                  </h4>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full font-mono font-bold">
                    Estimated 6Mo Revenue: {proposalResult.expected6MonthRevenue}
                  </span>
                </div>

                <p className="text-xs text-neutral-300 leading-relaxed font-light">
                  {proposalResult.executiveSummary}
                </p>

                <div className="space-y-3">
                  <h5 className="text-xs font-bold text-white uppercase tracking-wider">Recommended Growth Modules</h5>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {proposalResult.recommendedServices?.map((serv: any, idx: number) => (
                      <div key={idx} className="bg-black/60 p-3.5 rounded-xl border border-white/10 space-y-1">
                        <div className="text-xs font-bold text-white">{serv.name}</div>
                        <div className="text-[11px] text-[#D4AF37] font-semibold">{serv.cost}</div>
                        <div className="text-[10px] text-emerald-400 font-mono">{serv.roi}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

      </div>
    </section>
  );
};
